// LoginViewController.m
// Referência para integrar na FilzaApplySandboxExt. Ajuste API_BASE_URL e o ponto
// de apresentação ao controlador raiz real do Filza.
#import <UIKit/UIKit.h>
#import <QuartzCore/QuartzCore.h>
#import <Security/Security.h>

static NSString * const API_BASE_URL = @"https://filzaauth-ou4i5tqw.manus.space";
static NSString * const KeychainTag = @"com.filzaslop.device-key";
static NSString * const KeychainToken = @"com.filzaslop.device-token";

@interface LoginViewController : UIViewController
@end

@interface LoginViewController ()
@property(nonatomic,strong) UITextField *codeField;
@property(nonatomic,strong) UILabel *messageLabel;
@property(nonatomic,strong) UIButton *continueButton;
@property(nonatomic,assign) SecKeyRef privateKey;
@end

@implementation LoginViewController

- (void)dealloc { if (_privateKey) { CFRelease(_privateKey); _privateKey = NULL; } }

- (void)viewDidLoad {
  [super viewDidLoad];
  self.navigationController.navigationBarHidden = YES;
  self.view.backgroundColor = [UIColor colorWithRed:0.035 green:0.045 blue:0.075 alpha:1.0];

  CAGradientLayer *gradient = [CAGradientLayer layer];
  gradient.frame = self.view.bounds;
  gradient.colors = @[(id)[UIColor colorWithRed:0.06 green:0.10 blue:0.18 alpha:1.0].CGColor,
                      (id)[UIColor colorWithRed:0.16 green:0.10 blue:0.26 alpha:1.0].CGColor,
                      (id)[UIColor colorWithRed:0.03 green:0.05 blue:0.10 alpha:1.0].CGColor];
  gradient.startPoint = CGPointMake(0.0, 0.0);
  gradient.endPoint = CGPointMake(1.0, 1.0);
  [self.view.layer insertSublayer:gradient atIndex:0];

  UIVisualEffectView *glassCard = [[UIVisualEffectView alloc] initWithEffect:[UIBlurEffect effectWithStyle:UIBlurEffectStyleSystemMaterialDark]];
  glassCard.translatesAutoresizingMaskIntoConstraints = NO;
  glassCard.layer.cornerRadius = 30.0;
  glassCard.layer.cornerCurve = kCACornerCurveContinuous;
  glassCard.layer.borderWidth = 1.0;
  glassCard.layer.borderColor = [UIColor colorWithWhite:1.0 alpha:0.20].CGColor;
  glassCard.clipsToBounds = YES;
  [self.view addSubview:glassCard];

  self.codeField = [[UITextField alloc] initWithFrame:CGRectZero];
  self.codeField.translatesAutoresizingMaskIntoConstraints = NO;
  self.codeField.placeholder = @"Insira sua key";
  self.codeField.textColor = UIColor.whiteColor;
  self.codeField.tintColor = UIColor.whiteColor;
  self.codeField.backgroundColor = [UIColor colorWithWhite:1.0 alpha:0.10];
  self.codeField.layer.cornerRadius = 16.0;
  self.codeField.layer.borderWidth = 1.0;
  self.codeField.layer.borderColor = [UIColor colorWithWhite:1.0 alpha:0.16].CGColor;
  self.codeField.leftView = [[UIView alloc] initWithFrame:CGRectMake(0, 0, 16, 1)];
  self.codeField.leftViewMode = UITextFieldViewModeAlways;
  self.codeField.autocapitalizationType = UITextAutocapitalizationTypeAllCharacters;
  self.codeField.autocorrectionType = UITextAutocorrectionTypeNo;
  [glassCard.contentView addSubview:self.codeField];

  self.messageLabel = [[UILabel alloc] initWithFrame:CGRectZero];
  self.messageLabel.translatesAutoresizingMaskIntoConstraints = NO;
  self.messageLabel.numberOfLines = 0;
  self.messageLabel.textColor = [UIColor colorWithWhite:1.0 alpha:0.75];
  self.messageLabel.font = [UIFont systemFontOfSize:13.0 weight:UIFontWeightRegular];
  self.messageLabel.textAlignment = NSTextAlignmentCenter;
  self.messageLabel.text = @"";
  [glassCard.contentView addSubview:self.messageLabel];

  self.continueButton = [UIButton buttonWithType:UIButtonTypeSystem];
  self.continueButton.translatesAutoresizingMaskIntoConstraints = NO;
  [self.continueButton setTitle:@"Entrar" forState:UIControlStateNormal];
  self.continueButton.backgroundColor = [UIColor colorWithRed:0.36 green:0.53 blue:1.0 alpha:0.92];
  [self.continueButton setTitleColor:UIColor.whiteColor forState:UIControlStateNormal];
  self.continueButton.titleLabel.font = [UIFont systemFontOfSize:17.0 weight:UIFontWeightSemibold];
  self.continueButton.layer.cornerRadius = 16.0;
  self.continueButton.layer.borderWidth = 1.0;
  self.continueButton.layer.borderColor = [UIColor colorWithWhite:1.0 alpha:0.28].CGColor;
  [self.continueButton addTarget:self action:@selector(activate:) forControlEvents:UIControlEventTouchUpInside];
  [glassCard.contentView addSubview:self.continueButton];

  [NSLayoutConstraint activateConstraints:@[
    [glassCard.leadingAnchor constraintEqualToAnchor:self.view.leadingAnchor constant:24.0],
    [glassCard.trailingAnchor constraintEqualToAnchor:self.view.trailingAnchor constant:-24.0],
    [glassCard.centerYAnchor constraintEqualToAnchor:self.view.centerYAnchor],
    [glassCard.heightAnchor constraintEqualToConstant:270.0],
    [self.codeField.topAnchor constraintEqualToAnchor:glassCard.contentView.topAnchor constant:32.0],
    [self.codeField.leadingAnchor constraintEqualToAnchor:glassCard.contentView.leadingAnchor constant:22.0],
    [self.codeField.trailingAnchor constraintEqualToAnchor:glassCard.contentView.trailingAnchor constant:-22.0],
    [self.codeField.heightAnchor constraintEqualToConstant:54.0],
    [self.continueButton.topAnchor constraintEqualToAnchor:self.codeField.bottomAnchor constant:18.0],
    [self.continueButton.leadingAnchor constraintEqualToAnchor:self.codeField.leadingAnchor],
    [self.continueButton.trailingAnchor constraintEqualToAnchor:self.codeField.trailingAnchor],
    [self.continueButton.heightAnchor constraintEqualToConstant:54.0],
    [self.messageLabel.topAnchor constraintEqualToAnchor:self.continueButton.bottomAnchor constant:8.0],
    [self.messageLabel.leadingAnchor constraintEqualToAnchor:self.codeField.leadingAnchor],
    [self.messageLabel.trailingAnchor constraintEqualToAnchor:self.codeField.trailingAnchor],
    [self.messageLabel.bottomAnchor constraintEqualToAnchor:glassCard.contentView.bottomAnchor constant:-14.0]
  ]];

  [self ensureDeviceKey];
  [self validateStoredToken];
}

- (void)validateStoredToken {
  NSDictionary *query = @{(__bridge id)kSecClass:(__bridge id)kSecClassGenericPassword, (__bridge id)kSecAttrAccount:KeychainToken, (__bridge id)kSecReturnData:@YES}; CFTypeRef ref = NULL;
  if (SecItemCopyMatching((__bridge CFDictionaryRef)query, &ref) != errSecSuccess) return;
  NSData *data = CFBridgingRelease(ref); NSString *token = [[NSString alloc] initWithData:data encoding:NSUTF8StringEncoding]; if (!token.length) return;
  NSURL *url = [NSURL URLWithString:[API_BASE_URL stringByAppendingString:@"/api/device/validate"]]; NSMutableURLRequest *request = [NSMutableURLRequest requestWithURL:url]; request.HTTPMethod = @"POST"; [request setValue:[@"Bearer " stringByAppendingString:token] forHTTPHeaderField:@"Authorization"];
  [[[NSURLSession sharedSession] dataTaskWithRequest:request completionHandler:^(NSData *responseData, NSURLResponse *response, NSError *error) { BOOL valid = NO; if (!error && responseData) { NSDictionary *json = [NSJSONSerialization JSONObjectWithData:responseData options:0 error:nil]; valid = [json[@"valid"] boolValue]; } dispatch_async(dispatch_get_main_queue(), ^{ if (valid) [self dismissViewControllerAnimated:NO completion:nil]; else { SecItemDelete((__bridge CFDictionaryRef)@{(__bridge id)kSecClass:(__bridge id)kSecClassGenericPassword, (__bridge id)kSecAttrAccount:KeychainToken}); self.messageLabel.text = @"Esta ativação não está mais válida. Informe um novo código."; } }); }] resume];
}

- (void)ensureDeviceKey {
  NSData *tag = [KeychainTag dataUsingEncoding:NSUTF8StringEncoding];
  NSDictionary *query = @{(__bridge id)kSecClass:(__bridge id)kSecClassKey, (__bridge id)kSecAttrApplicationTag:tag, (__bridge id)kSecReturnRef:@YES};
  SecKeyRef existing = NULL;
  if (SecItemCopyMatching((__bridge CFDictionaryRef)query, (CFTypeRef *)&existing) == errSecSuccess) { self.privateKey = existing; return; }
  NSDictionary *attrs = @{(__bridge id)kSecAttrKeyType:(__bridge id)kSecAttrKeyTypeECSECPrimeRandom, (__bridge id)kSecAttrKeySizeInBits:@256, (__bridge id)kSecPrivateKeyAttrs:@{(__bridge id)kSecAttrIsPermanent:@YES, (__bridge id)kSecAttrApplicationTag:tag}};
  CFErrorRef error = NULL;
  self.privateKey = SecKeyCreateRandomKey((__bridge CFDictionaryRef)attrs, &error);
  if (error) CFRelease(error);
}

- (NSString *)publicKeyPEM {
  SecKeyRef pub = SecKeyCopyPublicKey(self.privateKey); CFErrorRef error = NULL;
  CFDataRef data = SecKeyCopyExternalRepresentation(pub, &error); if (pub) CFRelease(pub); if (!data) { if (error) CFRelease(error); return nil; }
  NSString *b64 = [(__bridge NSData *)data base64EncodedStringWithOptions:0]; CFRelease(data);
  return [NSString stringWithFormat:@"-----BEGIN PUBLIC KEY-----\n%@\n-----END PUBLIC KEY-----", b64];
}

- (void)postJSON:(NSDictionary *)body path:(NSString *)path completion:(void (^)(NSDictionary *, NSError *))completion {
  NSURL *url = [NSURL URLWithString:[API_BASE_URL stringByAppendingString:path]]; NSMutableURLRequest *request = [NSMutableURLRequest requestWithURL:url]; request.HTTPMethod = @"POST"; [request setValue:@"application/json" forHTTPHeaderField:@"Content-Type"]; request.HTTPBody = [NSJSONSerialization dataWithJSONObject:body options:0 error:nil];
  [[[NSURLSession sharedSession] dataTaskWithRequest:request completionHandler:^(NSData *data, NSURLResponse *response, NSError *error) { NSDictionary *json = data ? [NSJSONSerialization JSONObjectWithData:data options:0 error:nil] : nil; dispatch_async(dispatch_get_main_queue(), ^{ completion(json, error ?: ([json[@"error"] isKindOfClass:NSString.class] ? [NSError errorWithDomain:@"FilzaAuth" code:1 userInfo:@{NSLocalizedDescriptionKey:json[@"error"]}] : nil)); }); }] resume];
}

- (void)activate:(id)sender {
  NSString *code = [self.codeField.text stringByTrimmingCharactersInSet:NSCharacterSet.whitespaceAndNewlineCharacterSet]; NSString *pub = [self publicKeyPEM]; if (!code.length || !pub.length) { self.messageLabel.text = @"Insira sua key para continuar."; return; }
  self.continueButton.enabled = NO; [self postJSON:@{ @"activationCode":code, @"publicKey":pub, @"deviceName":UIDevice.currentDevice.name ?: @"iPhone", @"appVersion":NSBundle.mainBundle.infoDictionary[@"CFBundleShortVersionString"] ?: @"unknown" } path:@"/api/device/activate" completion:^(NSDictionary *json, NSError *error) {
    if (error) { self.continueButton.enabled = YES; self.messageLabel.text = error.localizedDescription; return; }
    [self requestChallenge];
  }];
}

- (void)requestChallenge {
  [self postJSON:@{ @"publicKey": [self publicKeyPEM] } path:@"/api/device/auth" completion:^(NSDictionary *json, NSError *error) {
    if (error) { self.continueButton.enabled = YES; self.messageLabel.text = error.localizedDescription; return; }
    NSString *challenge = json[@"challenge"]; NSData *message = [challenge dataUsingEncoding:NSUTF8StringEncoding]; CFErrorRef signingError = NULL; CFDataRef sig = SecKeyCreateSignature(self.privateKey, kSecKeyAlgorithmECDSASignatureMessageX962SHA256, (__bridge CFDataRef)message, &signingError); if (!sig) { self.messageLabel.text = @"Não foi possível assinar o desafio."; self.continueButton.enabled = YES; if (signingError) CFRelease(signingError); return; }
    NSString *signature = [(__bridge NSData *)sig base64EncodedStringWithOptions:0]; CFRelease(sig);
    [self postJSON:@{ @"publicKey":[self publicKeyPEM], @"challenge":challenge, @"signature":signature } path:@"/api/device/auth" completion:^(NSDictionary *auth, NSError *authError) {
      self.continueButton.enabled = YES; if (authError) { self.messageLabel.text = authError.localizedDescription; return; }
      NSData *tokenData = [auth[@"token"] dataUsingEncoding:NSUTF8StringEncoding]; NSDictionary *item = @{(__bridge id)kSecClass:(__bridge id)kSecClassGenericPassword, (__bridge id)kSecAttrAccount:KeychainToken, (__bridge id)kSecValueData:tokenData, (__bridge id)kSecAttrAccessible:(__bridge id)kSecAttrAccessibleAfterFirstUnlockThisDeviceOnly}; SecItemDelete((__bridge CFDictionaryRef)@{(__bridge id)kSecClass:(__bridge id)kSecClassGenericPassword, (__bridge id)kSecAttrAccount:KeychainToken}); SecItemAdd((__bridge CFDictionaryRef)item, NULL);
      [self dismissViewControllerAnimated:YES completion:nil];
    }];
  }];
}
@end
