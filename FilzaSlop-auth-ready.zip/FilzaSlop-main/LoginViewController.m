// LoginViewController.m
// Referência para integrar na FilzaApplySandboxExt. Ajuste API_BASE_URL e o ponto
// de apresentação ao controlador raiz real do Filza.
#import <UIKit/UIKit.h>
#import <QuartzCore/QuartzCore.h>
#import <Security/Security.h>

static NSString * const API_BASE_URL = @"https://filzaauth-ou4i5tqw.manus.space";
static NSString * const KeychainTag = @"com.filzaslop.device-key";
static NSString * const KeychainToken = @"com.filzaslop.device-token";

@interface LoginViewController : UIViewController
@end

@interface LoginViewController ()
@property(nonatomic,strong) UITextField *codeField;
@property(nonatomic,strong) UILabel *messageLabel;
@property(nonatomic,strong) UIButton *continueButton;
@property(nonatomic,assign) SecKeyRef privateKey;
@end

@implementation LoginViewController

- (void)dealloc { if (_privateKey) { CFRelease(_privateKey); _privateKey = NULL; } }

- (void)viewDidLoad {
  [super viewDidLoad];
  self.navigationController.navigationBarHidden = YES;
  // Fundo sólido e estático: sem partículas, vídeo ou animações.
  self.view.backgroundColor = [UIColor colorWithRed:0.025 green:0.03 blue:0.055 alpha:1.0];

  UIView *glassCard = [[UIView alloc] initWithFrame:CGRectZero];
  glassCard.translatesAutoresizingMaskIntoConstraints = NO;
  glassCard.layer.cornerRadius = 30.0;
  glassCard.layer.cornerCurve = kCACornerCurveContinuous;
  glassCard.layer.borderWidth = 1.0;
  glassCard.layer.borderColor = [UIColor colorWithRed:0.16 green:0.35 blue:0.75 alpha:0.72].CGColor;
  glassCard.backgroundColor = [UIColor colorWithRed:0.035 green:0.04 blue:0.07 alpha:0.98];
  glassCard.clipsToBounds = YES;
  [self.view addSubview:glassCard];

  UILabel *titleLabel = [[UILabel alloc] initWithFrame:CGRectZero];
  titleLabel.translatesAutoresizingMaskIntoConstraints = NO;
  titleLabel.text = @"Filza";
  titleLabel.textColor = [UIColor colorWithRed:0.38 green:0.62 blue:1.0 alpha:1.0];
  titleLabel.font = [UIFont systemFontOfSize:30.0 weight:UIFontWeightBold];
  titleLabel.textAlignment = NSTextAlignmentCenter;
  [glassCard addSubview:titleLabel];

  UILabel *subtitleLabel = [[UILabel alloc] initWithFrame:CGRectZero];
  subtitleLabel.translatesAutoresizingMaskIntoConstraints = NO;
  subtitleLabel.text = @"Valide sua key para continuar";
  subtitleLabel.textColor = [UIColor colorWithWhite:1.0 alpha:0.72];
  subtitleLabel.font = [UIFont systemFontOfSize:15.0 weight:UIFontWeightRegular];
  subtitleLabel.textAlignment = NSTextAlignmentCenter;
  [glassCard addSubview:subtitleLabel];

  self.codeField = [[UITextField alloc] initWithFrame:CGRectZero];
  self.codeField.translatesAutoresizingMaskIntoConstraints = NO;
  self.codeField.placeholder = @"Cole sua key aqui";
  self.codeField.textColor = UIColor.whiteColor;
  self.codeField.tintColor = UIColor.whiteColor;
  self.codeField.backgroundColor = [UIColor colorWithWhite:1.0 alpha:0.10];
  self.codeField.layer.cornerRadius = 16.0;
  self.codeField.layer.borderWidth = 1.0;
  self.codeField.layer.borderColor = [UIColor colorWithWhite:1.0 alpha:0.16].CGColor;
  self.codeField.leftView = [[UIView alloc] initWithFrame:CGRectMake(0, 0, 16, 1)];
  self.codeField.leftViewMode = UITextFieldViewModeAlways;
  self.codeField.autocapitalizationType = UITextAutocapitalizationTypeAllCharacters;
  self.codeField.autocorrectionType = UITextAutocorrectionTypeNo;
  [glassCard addSubview:self.codeField];

  self.messageLabel = [[UILabel alloc] initWithFrame:CGRectZero];
  self.messageLabel.translatesAutoresizingMaskIntoConstraints = NO;
  self.messageLabel.numberOfLines = 0;
  self.messageLabel.textColor = [UIColor colorWithWhite:1.0 alpha:0.75];
  self.messageLabel.font = [UIFont systemFontOfSize:13.0 weight:UIFontWeightRegular];
  self.messageLabel.textAlignment = NSTextAlignmentCenter;
  self.messageLabel.text = @"";
  [glassCard addSubview:self.messageLabel];

  self.continueButton = [UIButton buttonWithType:UIButtonTypeSystem];
  self.continueButton.translatesAutoresizingMaskIntoConstraints = NO;
  [self.continueButton setTitle:@"Entrar" forState:UIControlStateNormal];
  self.continueButton.backgroundColor = [UIColor colorWithRed:0.36 green:0.53 blue:1.0 alpha:0.92];
  [self.continueButton setTitleColor:UIColor.whiteColor forState:UIControlStateNormal];
  self.continueButton.titleLabel.font = [UIFont systemFontOfSize:17.0 weight:UIFontWeightSemibold];
  self.continueButton.layer.cornerRadius = 16.0;
  self.continueButton.layer.borderWidth = 1.0;
  self.continueButton.layer.borderColor = [UIColor colorWithWhite:1.0 alpha:0.28].CGColor;
  [self.continueButton addTarget:self action:@selector(activate:) forControlEvents:UIControlEventTouchUpInside];
  [glassCard addSubview:self.continueButton];

  [NSLayoutConstraint activateConstraints:@[
    [glassCard.leadingAnchor constraintEqualToAnchor:self.view.leadingAnchor constant:24.0],
    [glassCard.trailingAnchor constraintEqualToAnchor:self.view.trailingAnchor constant:-24.0],
    [glassCard.centerYAnchor constraintEqualToAnchor:self.view.centerYAnchor],
    [glassCard.heightAnchor constraintEqualToConstant:330.0],
    [titleLabel.topAnchor constraintEqualToAnchor:glassCard.topAnchor constant:28.0],
    [titleLabel.leadingAnchor constraintEqualToAnchor:glassCard.leadingAnchor constant:22.0],
    [titleLabel.trailingAnchor constraintEqualToAnchor:glassCard.trailingAnchor constant:-22.0],
    [subtitleLabel.topAnchor constraintEqualToAnchor:titleLabel.bottomAnchor constant:6.0],
    [subtitleLabel.leadingAnchor constraintEqualToAnchor:glassCard.leadingAnchor constant:22.0],
    [subtitleLabel.trailingAnchor constraintEqualToAnchor:glassCard.trailingAnchor constant:-22.0],
    [self.codeField.topAnchor constraintEqualToAnchor:subtitleLabel.bottomAnchor constant:26.0],
    [self.codeField.leadingAnchor constraintEqualToAnchor:glassCard.leadingAnchor constant:22.0],
    [self.codeField.trailingAnchor constraintEqualToAnchor:glassCard.trailingAnchor constant:-22.0],
    [self.codeField.heightAnchor constraintEqualToConstant:54.0],
    [self.continueButton.topAnchor constraintEqualToAnchor:self.codeField.bottomAnchor constant:18.0],
    [self.continueButton.leadingAnchor constraintEqualToAnchor:self.codeField.leadingAnchor],
    [self.continueButton.trailingAnchor constraintEqualToAnchor:self.codeField.trailingAnchor],
    [self.continueButton.heightAnchor constraintEqualToConstant:54.0],
    [self.messageLabel.topAnchor constraintEqualToAnchor:self.continueButton.bottomAnchor constant:8.0],
    [self.messageLabel.leadingAnchor constraintEqualToAnchor:self.codeField.leadingAnchor],
    [self.messageLabel.trailingAnchor constraintEqualToAnchor:self.codeField.trailingAnchor],
    [self.messageLabel.bottomAnchor constraintEqualToAnchor:glassCard.bottomAnchor constant:-14.0]
  ]];

  [self ensureDeviceKey];
  [self validateStoredToken];
}

- (void)validateStoredToken {
  NSDictionary *query = @{(__bridge id)kSecClass:(__bridge id)kSecClassGenericPassword, (__bridge id)kSecAttrAccount:KeychainToken, (__bridge id)kSecReturnData:@YES}; CFTypeRef ref = NULL;
  if (SecItemCopyMatching((__bridge CFDictionaryRef)query, &ref) != errSecSuccess) return;
  NSData *data = CFBridgingRelease(ref); NSString *token = [[NSString alloc] initWithData:data encoding:NSUTF8StringEncoding]; if (!token.length) return;
  NSURL *url = [NSURL URLWithString:[API_BASE_URL stringByAppendingString:@"/api/device/validate"]]; NSMutableURLRequest *request = [NSMutableURLRequest requestWithURL:url]; request.HTTPMethod = @"POST"; [request setValue:[@"Bearer " stringByAppendingString:token] forHTTPHeaderField:@"Authorization"];
  [[[NSURLSession sharedSession] dataTaskWithRequest:request completionHandler:^(NSData *responseData, NSURLResponse *response, NSError *error) { BOOL valid = NO; if (!error && responseData) { NSDictionary *json = [NSJSONSerialization JSONObjectWithData:responseData options:0 error:nil]; valid = [json[@"valid"] boolValue]; } dispatch_async(dispatch_get_main_queue(), ^{ if (valid) [self dismissViewControllerAnimated:NO completion:nil]; else { SecItemDelete((__bridge CFDictionaryRef)@{(__bridge id)kSecClass:(__bridge id)kSecClassGenericPassword, (__bridge id)kSecAttrAccount:KeychainToken}); self.messageLabel.text = @"Esta ativação não está mais válida. Informe um novo código."; } }); }] resume];
}

- (void)ensureDeviceKey {
  NSData *tag = [KeychainTag dataUsingEncoding:NSUTF8StringEncoding];
  NSDictionary *query = @{(__bridge id)kSecClass:(__bridge id)kSecClassKey, (__bridge id)kSecAttrApplicationTag:tag, (__bridge id)kSecReturnRef:@YES};
  SecKeyRef existing = NULL;
  if (SecItemCopyMatching((__bridge CFDictionaryRef)query, (CFTypeRef *)&existing) == errSecSuccess) { self.privateKey = existing; return; }
  NSDictionary *attrs = @{(__bridge id)kSecAttrKeyType:(__bridge id)kSecAttrKeyTypeECSECPrimeRandom, (__bridge id)kSecAttrKeySizeInBits:@256, (__bridge id)kSecPrivateKeyAttrs:@{(__bridge id)kSecAttrIsPermanent:@YES, (__bridge id)kSecAttrApplicationTag:tag}};
  CFErrorRef error = NULL;
  self.privateKey = SecKeyCreateRandomKey((__bridge CFDictionaryRef)attrs, &error);
  if (error) CFRelease(error);
}

- (NSString *)publicKeyPEM {
  SecKeyRef pub = SecKeyCopyPublicKey(self.privateKey);
  if (!pub) return nil;
  CFErrorRef error = NULL;
  CFDataRef rawData = SecKeyCopyExternalRepresentation(pub, &error);
  CFRelease(pub);
  if (!rawData) { if (error) CFRelease(error); return nil; }

  NSData *raw = (__bridge NSData *)rawData;
  // SecKey exports a P-256 public key as an ANSI X9.63 point (0x04 || X || Y).
  // The API expects the same key encoded as SubjectPublicKeyInfo (SPKI) PEM.
  if (raw.length != 65 || ((const unsigned char *)raw.bytes)[0] != 0x04) {
    CFRelease(rawData);
    return nil;
  }
  static const unsigned char spkiPrefix[] = {
    0x30, 0x59, 0x30, 0x13, 0x06, 0x07, 0x2A, 0x86, 0x48, 0xCE, 0x3D, 0x02, 0x01,
    0x06, 0x08, 0x2A, 0x86, 0x48, 0xCE, 0x3D, 0x03, 0x01, 0x07, 0x03, 0x42, 0x00
  };
  NSMutableData *spki = [NSMutableData dataWithBytes:spkiPrefix length:sizeof(spkiPrefix)];
  [spki appendBytes:raw.bytes length:raw.length];
  CFRelease(rawData);
  NSString *b64 = [spki base64EncodedStringWithOptions:0];
  return [NSString stringWithFormat:@"-----BEGIN PUBLIC KEY-----\n%@\n-----END PUBLIC KEY-----", b64];
}

- (void)postJSON:(NSDictionary *)body path:(NSString *)path completion:(void (^)(NSDictionary *, NSError *))completion {
  NSURL *url = [NSURL URLWithString:[API_BASE_URL stringByAppendingString:path]]; NSMutableURLRequest *request = [NSMutableURLRequest requestWithURL:url]; request.HTTPMethod = @"POST"; [request setValue:@"application/json" forHTTPHeaderField:@"Content-Type"]; request.HTTPBody = [NSJSONSerialization dataWithJSONObject:body options:0 error:nil];
  [[[NSURLSession sharedSession] dataTaskWithRequest:request completionHandler:^(NSData *data, NSURLResponse *response, NSError *error) { NSDictionary *json = data ? [NSJSONSerialization JSONObjectWithData:data options:0 error:nil] : nil; dispatch_async(dispatch_get_main_queue(), ^{ completion(json, error ?: ([json[@"error"] isKindOfClass:NSString.class] ? [NSError errorWithDomain:@"FilzaAuth" code:1 userInfo:@{NSLocalizedDescriptionKey:json[@"error"]}] : nil)); }); }] resume];
}

- (void)activate:(id)sender {
  NSString *code = [self.codeField.text stringByTrimmingCharactersInSet:NSCharacterSet.whitespaceAndNewlineCharacterSet]; NSString *pub = [self publicKeyPEM]; if (!code.length || !pub.length) { self.messageLabel.text = @"Insira sua key para continuar."; return; }
  self.continueButton.enabled = NO; [self postJSON:@{ @"activationCode":code, @"publicKey":pub, @"deviceName":UIDevice.currentDevice.name ?: @"iPhone", @"appVersion":NSBundle.mainBundle.infoDictionary[@"CFBundleShortVersionString"] ?: @"unknown" } path:@"/api/device/activate" completion:^(NSDictionary *json, NSError *error) {
    if (error) { self.continueButton.enabled = YES; self.messageLabel.text = error.localizedDescription; return; }
    [self requestChallenge];
  }];
}

- (void)requestChallenge {
  [self postJSON:@{ @"publicKey": [self publicKeyPEM] } path:@"/api/device/auth" completion:^(NSDictionary *json, NSError *error) {
    if (error) { self.continueButton.enabled = YES; self.messageLabel.text = error.localizedDescription; return; }
    NSString *challenge = json[@"challenge"]; NSData *message = [challenge dataUsingEncoding:NSUTF8StringEncoding]; CFErrorRef signingError = NULL; CFDataRef sig = SecKeyCreateSignature(self.privateKey, kSecKeyAlgorithmECDSASignatureMessageX962SHA256, (__bridge CFDataRef)message, &signingError); if (!sig) { self.messageLabel.text = @"Não foi possível assinar o desafio."; self.continueButton.enabled = YES; if (signingError) CFRelease(signingError); return; }
    NSString *signature = [(__bridge NSData *)sig base64EncodedStringWithOptions:0]; CFRelease(sig);
    [self postJSON:@{ @"publicKey":[self publicKeyPEM], @"challenge":challenge, @"signature":signature } path:@"/api/device/auth" completion:^(NSDictionary *auth, NSError *authError) {
      self.continueButton.enabled = YES; if (authError) { self.messageLabel.text = authError.localizedDescription; return; }
      NSData *tokenData = [auth[@"token"] dataUsingEncoding:NSUTF8StringEncoding]; NSDictionary *item = @{(__bridge id)kSecClass:(__bridge id)kSecClassGenericPassword, (__bridge id)kSecAttrAccount:KeychainToken, (__bridge id)kSecValueData:tokenData, (__bridge id)kSecAttrAccessible:(__bridge id)kSecAttrAccessibleAfterFirstUnlockThisDeviceOnly}; SecItemDelete((__bridge CFDictionaryRef)@{(__bridge id)kSecClass:(__bridge id)kSecClassGenericPassword, (__bridge id)kSecAttrAccount:KeychainToken}); SecItemAdd((__bridge CFDictionaryRef)item, NULL);
      [self dismissViewControllerAnimated:YES completion:nil];
    }];
  }];
}
@end
