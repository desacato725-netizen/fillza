# Upload simples pelo celular

1. No repositório público `desacato725-netizen/fillza`, use **Add file → Upload files** e envie somente `FilzaSlop-auth-ready.zip`. Faça o commit na branch `main`.
2. Use **Add file → Create new file** e crie exatamente `.github/workflows/build-from-zip.yml`.
3. Copie o conteúdo do arquivo `build-from-zip.yml` deste pacote e cole no editor do GitHub. Faça o commit.
4. Abra **Actions → Build FilzaApplySandboxExt from ZIP → Run workflow**.
5. O runner macOS extrairá o ZIP, encontrará o `Makefile`, instalará Theos, compilará arm64/arm64e e publicará o artefato unsigned.

O workflow standalone existe porque o GitHub não extrai automaticamente arquivos ZIP enviados ao repositório. Não envie certificados, chaves privadas, provisioning profiles, senhas ou tokens.
