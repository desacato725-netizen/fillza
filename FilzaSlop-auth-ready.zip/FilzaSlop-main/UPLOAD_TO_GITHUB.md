# Upload e compilação pelo celular

1. Abra o repositório público `desacato725-netizen/fillza` no GitHub.
2. Toque em **Add file → Upload files**.
3. Extraia este ZIP antes do upload, ou envie o conteúdo da pasta `FilzaSlop-main` para a raiz do repositório. A raiz precisa conter `Makefile`, `Tweak.m`, `.github/workflows/build-filza-dylib.yml` e `scripts/collect_unsigned_artifacts.sh`.
4. Faça o commit diretamente na branch `main`.
5. Abra **Actions**, selecione **Build FilzaApplySandboxExt**, toque em **Run workflow** e confirme.
6. Quando o job terminar com sucesso, abra a execução e baixe o artefato `FilzaApplySandboxExt-unsigned-*`.

O workflow compila a dylib em runner macOS e não assina a IPA. Não envie certificados, chaves privadas, provisioning profiles, senhas ou tokens ao repositório. A assinatura e a instalação final continuam sujeitas à compatibilidade do iOS, do método de sideload e dos identificadores exigidos pelo FilzaSlop.
